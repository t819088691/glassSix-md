#!/bin/bash
mkdir -p /var/lib/containerd
mkfs.xfs   /dev/vdb
mount /dev/vdb /var/lib/containerd
echo "/dev/vdb /var/lib/containerd                       xfs     defaults        0 0" |tee -a  /etc/fstab
echo "export KKZONE=cn" |tee  -a /etc/profile
source /etc/profile
systemctl enable --now iscsid
